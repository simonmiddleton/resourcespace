These images are from the silk icon set, and are licensed under the
Creative Commons Attribution 2.5 License.

See:
http://famfamfam.com/lab/icons/silk/
