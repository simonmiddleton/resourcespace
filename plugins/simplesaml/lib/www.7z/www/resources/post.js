/**
 * Automatically click the input button to redirect the user to
 * the SSO
 */
window.onload = function(){
    document.getElementById('postLoginSubmitButton').click();
};